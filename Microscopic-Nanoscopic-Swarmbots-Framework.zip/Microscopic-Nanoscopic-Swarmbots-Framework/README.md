# Microscopic & Nanoscopic Swarmbots Framework

This repository is structured in four evolutionary layers:

1. Research
2. Simulator
3. Security
4. Foundational AI

The system is designed as a research-first, sandboxed swarm intelligence architecture.
