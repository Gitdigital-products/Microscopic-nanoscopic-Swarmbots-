# Experiment 001 - Cluster Formation

Parameters, expectations, observations.