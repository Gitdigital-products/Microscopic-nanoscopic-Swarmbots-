# Agent Protocol

Communication schema and coordination rules.