# Threat Model

Document potential misuse and instability risks.