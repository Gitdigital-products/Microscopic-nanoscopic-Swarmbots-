# Sandboxing Strategy

Execution isolation and limits.