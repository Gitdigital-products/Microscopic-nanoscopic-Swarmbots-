# Collision model placeholder
