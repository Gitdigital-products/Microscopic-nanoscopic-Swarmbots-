# Hypotheses

Document testable swarm behavior hypotheses here.